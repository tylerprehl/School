/**
 * CSC 402-02 Assignment #4
 * 
 * On my honor, <Your Full Name>, this assignment is my own work.  
 * I, <Your Full Name>, will follow the instructor's rules and processes 
 * related to academic integrity as directed in the course syllabus.
 *
 */

package p.actions;

import org.eclipse.jdt.core.dom.ASTVisitor; 

public class ASTVisitorEx extends ASTVisitor {
 

}

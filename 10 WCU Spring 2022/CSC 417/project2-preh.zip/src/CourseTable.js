import React, { Component } from "react";
import CourseRow from "./CourseRow";
//import { writingCourses } from "./FilterableCourseTable";





export  class CourseTable extends Component {
  
  getTableType() {
    console.log(this.props.courses.length)
    if (this.props.courses.length===0) {
      return "Additional Courses"
    }
    let emphasis = this.props.courses[0].description
    if (emphasis === "Writing1") {
      return "Writing Emphasis"
    }
    else if (emphasis === "Speaking1") {
      return "Speaking Emphasis"
    }
    else {
      return "Additional Courses"
    }
  }

  render() {
    const name = this.props.name;
    const credit = this.props.credit;
    
    const courses = this.props.courses;
    
    

    const rows = [];
    console.log("--- CourseTable ---");
    console.log ("Name:" + name);
    console.log ("Credit:" + credit);
    courses.forEach((c) => {
      console.log("Received a course: " + c.id + " "+ c.prefix + " "+ c.number);

      
      
      if (c.id === 1) {
        console.log("--course 1 " + c.course);
        rows.push(
          <CourseRow
            course={c}
            key={c.id} 
            editCallback= { this.props.editCallback }
          />
        );
      }
      if (c.id === 2 && credit < 71) {
        console.log("--course 2 " + c.course);
        rows.push(
          <CourseRow
            course={c}
            key={c.id}
            editCallback= { this.props.editCallback }
          />
        );
      }
      if (c.id === 3 && credit < 40) {
        console.log("--course 3 " + c.course);
        rows.push(
          <CourseRow
            course={c}
            key={c.id}
            editCallback= { this.props.editCallback }
          />
        );
      }
        
    });
   
    console.log(`{name}`);
    return (
      <table className="table table-sm table-striped table-bordered">
        <thead>
          <tr>
            <th colSpan="7" className="bg-primary text-white text-center h4 p-2">
              { this.getTableType() } for {this.props.name}
            </th>
          </tr> 
          <tr>
            <th>ID</th>
            <th>Description</th>
            <th>Semester</th>
            <th>Prefix</th>
            <th>Number</th>
            <th>Grade</th>
            <th>Editing</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
    );
  }
}
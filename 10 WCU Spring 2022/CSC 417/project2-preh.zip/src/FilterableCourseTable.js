import React, { Component } from "react";
import InfoBar from "./InfoBar";
import CourseDisplay from "./CourseDisplay";
//import CourseDisplaySpeaking from "./CourseDisplaySpeaking";




export default class FilterableCourseTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      credits: 0,
      speakingCourses : [
        {id: 1, description: "Speaking1",semester:'' , prefix:'SPK', number: '208/230', grade: '  '},
        {id: 2, description: "Speaking2",semester:'' , prefix:'', number: '  ', grade: '  '},
        {id: 3, description: "Speaking3",semester:'' , prefix:'', number: '  ', grade: '  '}
      ], 
      writingCourses : [
        {id: 1, description: "Writing1",semester:'' , prefix:'ENG', number: '368/371', grade: '  '},
        {id: 2, description: "Writing2",semester:'' , prefix:'', number: '  ', grade: '  '},
        {id: 3, description: "Writing3",semester:'' , prefix:'', number: '  ', grade: '  '}
      ],
      newCourses : [
        {id: 1, description: "Intro to Computer Science",semester:'' , prefix:'', number: '', grade: '  '},
        {id: 2, description: "Data Structures",semester:'' , prefix:'', number: '  ', grade: '  '},
        {id: 3, description: "User Interfaces",semester:'' , prefix:'', number: '  ', grade: '  '}
      ],
      showAdditional: false
    };

    this.handleNameChange = this.handleNameChange.bind(this);
    this.handleCreditChange = this.handleCreditChange.bind(this);
  }


  handleNameChange(studentName) {
    this.setState({
      name: studentName
    });
  }
  
  handleCreditChange(trCredit) {
    this.setState({
      credits: trCredit
    })
  }

  saveData = (collection, item) => {
    console.log("*** Collection: " + collection);
    console.log("*** Item:" + item);
      if (item.id === "") {
          item.id = this.idCounter++;
          this.setState(state => state[collection] 
              = state[collection].concat(item));
      } else {
          this.setState(state => state[collection] 
              = state[collection].map(stored => 
                    stored.id === item.id ? item: stored))
                    
      } 
  }

  deleteData = (collection, item) => {
    this.setState(state => state[collection] 
        = state[collection].filter(stored => stored.id !== item.id));
  }

  addAdditionalCourses = () => {
    if (this.state.showAdditional) {
      return <CourseDisplay
                    name={this.state.name}
                    credit={this.state.credits}
                    courses={ this.state.newCourses }
                    saveCallback={ c => this.saveData("newCourses", c) }
                    deleteCallback={ c => this.deleteData("newCourses", c) } 
      />
    } 
  }

  changeAdditional = () => {
    if (this.state.showAdditional) {
      this.setState( {showAdditional: false} )
      console.log("changed to not showing");
    }
    else {
      this.setState( {showAdditional: true} )
      console.log("changed to showing");
    }
  }


  render() {
    console.log("--- FilterableCourseTable ---");
    return (
      <div>
        <InfoBar
          name={this.state.name}
          credit={this.state.credits}
          onNameChange={this.handleNameChange}
          onCreditChange={this.handleCreditChange}
        />
        <CourseDisplay  
                    name={this.state.name}
                    credit={this.state.credits}
                    courses={ this.state.writingCourses }
                    saveCallback={ c => this.saveData("writingCourses", c) }
                    deleteCallback={ c => this.deleteData("writingCourses", c) } 
        />
        <CourseDisplay
                    name={this.state.name}
                    credit={this.state.credits}
                    courses={ this.state.speakingCourses }
                    saveCallback={ c => this.saveData("speakingCourses", c) }
                    deleteCallback={ c => this.deleteData("speakingCourses", c) } 
        />
        <button className="btn btn-primary m-1"
                onClick={ this.changeAdditional }>
                Additional Courses
        </button>
        { this.addAdditionalCourses() }
      </div>
    );
  }
}

/*
export const writingCourses = [
  {id: 1, description: "Writing1",semester:'' , prefix:'ENG', number: '368/371', grade: '  '},
  {id: 2, description: "Writing2",semester:'' , prefix:'WRI', number: '  ', grade: '  '},
  {id: 3, description: "Writing3",semester:'' , prefix:'ABC', number: '  ', grade: '  '},
];*/
/* moved into index.js
ReactDOM.render(
  <FilterableProductTable products={PRODUCTS} />,
  document.getElementById('container')
);

<div className="text-left">
  <button className="btn btn-primary m-1"
        background-color="#841584"
        onClick={ this.changeAdditional() }>
        Additional Courses
  </button>
</div>
*/



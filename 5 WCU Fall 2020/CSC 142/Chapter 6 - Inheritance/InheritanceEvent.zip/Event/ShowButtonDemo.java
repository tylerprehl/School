/** Demonstrates the class ButtonDemo */
public class ShowButtonDemo
{
    public static void main(String[] args)
    {
        ButtonDemo gui = new ButtonDemo( );
        gui.setVisible(true);
    }
}
